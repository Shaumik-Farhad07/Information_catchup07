var info = "";
for(let i=1; i<=8; i++){
    const place = ["Null", "Dhaka", "Rajshahi", "Chittagong", "Mymensingh", "Sylhet", "Rangpur", "Khulna", "Barishal"];
    const link = ["Null", "dhaka", "Rajshahi", "Chattogram", "Mymensingh", "Sylhet", "Rangpur", "Khulna", "Barishal"];
    info += `<div class="box">
                <img src="\images/img-${i}.jpg" alt="img-${i}">
                <h1>${place[i]}</h1>
                <a href="${link[i]}/index.html"><button>Click Here</button></a>
            </div>`;
}

document.querySelector(".region-content").innerHTML = info;