var info = "";
for(let i=1; i<=6; i++){
    const place = ["Null", "First Capital University of Bangladesh", "North Western University", "Northern University of Business & Technology, Khulna", "Rabindra Maitree University, Kushtia", "Khulna Khan Bahadur Ahsanullah University", "Bangladesh Army University of Science and Technology, Khulna"];
    const link = ["Null", "https://fcub.edu.bd/", "https://www.nwu.edu.bd/", "https://nubtkhulna.ac.bd/", "https://rmu.ac.bd/", "https://www.kkbau.ac.bd/", "https://baustk.mist.ac.bd/"];
    info += `<div class="box">
                <img src="\images/img-${i}.jpg" alt="img-${i}">
                <h5>${place[i]}</h5>
                <a href="${link[i]}/index.html"><button>Click Here</button></a>
            </div>`;
}

document.querySelector(".khulna-content").innerHTML = info;