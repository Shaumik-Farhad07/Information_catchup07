var info = "";
for(let i=1; i<=16; i++){
    const place = ["Null", "University of Science & Technology Chittagong", "International Islamic University Chittagong", "BGC Trust University Bangladesh", "Premier University", "East Delta University", "Feni University", "Britannia University", "Port City International University","Chittagong Independent University","Cox's Bazar International University","CCN University of Science & Technology","Bangladesh Army International University of Science & Technology (BAIUST), Comilla","University of Creative Technology, Chittagong","Bandarban University","University of Brahmanbaria","Chattogram BGMEA University of Fashion and Technology"];
    const link = ["Null", "https://ustc.ac.bd/", "https://www.iiuc.ac.bd/", "https://www.bgctub-edu.net/php_files/standard/user_home/user_home.php?home=yes&tm=main", "https://puc.ac.bd/", "https://www.eastdelta.edu.bd/", "https://feniuniversity.ac.bd/", "https://britannia.edu.bd/", "https://www.portcity.edu.bd/","https://www.ciu.edu.bd/","https://ciu.ac.bd/","http://www.ccnust.edu.bd/","https://baiust.ac.bd/","https://www.uctc.edu.bd/","https://bubban.edu.bd/","https://uob.edu.bd/","https://cbuft.edu.bd/"];
    info += `<div class="box">
                <img src="\images/img-${i}.jpg" alt="img-${i}">
                <h5>${place[i]}</h5>
                <a href="${link[i]}/index.html"><button>Click Here</button></a>
            </div>`;
}

document.querySelector(".Chattogram-content").innerHTML = info;