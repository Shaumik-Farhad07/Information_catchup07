var info = "";
for(let i=1; i<=8; i++){
    const place = ["Null", "Pundra University of Science & Technology", "Varendra University", "Exim Bank Agricultural University, Bangladesh", "Khwaja Yunus Ali University", "North Bengal International University", "Rajshahi Science & Technology University (RSTU), Natore","Bangladesh Army University of Engineering and Technology,Qadirabad","Ahsania Mission University of Science and Technology"];
    const link = ["Null", "https://pundrauniversity.ac.bd/", "https://vu.edu.bd/", "https://ebaub.ac.bd/", "https://www.kyau.edu.bd/", "https://www.nbiu.edu.bd/", "https://www.rstu.edu.bd/","https://bauet.ac.bd/","https://amust.ac.bd/"];
    info += `<div class="box">
                <img src="\images/img-${i}.jpg" alt="img-${i}">
                <h5>${place[i]}</h5>
                <a href="${link[i]}/index.html"><button>Click Here</button></a>
            </div>`;
}

document.querySelector(".Rajshahi-content").innerHTML = info;